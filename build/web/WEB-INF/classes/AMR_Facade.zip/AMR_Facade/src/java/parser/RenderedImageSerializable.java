/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.Serializable;




/**
 *
 * @author Jenia
 */
public class RenderedImageSerializable {
    
}
