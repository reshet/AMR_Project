package utilities;

///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package utilities;
//
//import java.io.Serializable;
//import javax.persistence.Embeddable;
//
///**
// *
// * @author Администратор
// */
//@Embeddable
//public class Content implements Serializable{
//    private Serializable content;
//    
//    public*
//}
